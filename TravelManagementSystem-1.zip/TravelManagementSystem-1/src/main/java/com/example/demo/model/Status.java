package com.example.demo.model;

public enum Status {

	ACTIVE,
	INACTIVE
}
