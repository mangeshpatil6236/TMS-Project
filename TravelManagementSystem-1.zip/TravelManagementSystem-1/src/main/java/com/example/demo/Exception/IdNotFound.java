package com.example.demo.Exception;

public class IdNotFound extends RuntimeException{
	
	public IdNotFound(String msg) {
		super(msg);
	}

}
